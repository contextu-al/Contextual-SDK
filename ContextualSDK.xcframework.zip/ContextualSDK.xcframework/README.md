# Contextual iOS SDK

[![Version](https://img.shields.io/cocoapods/v/Contextual.svg?style=flat)](http://cocoadocs.org/docsets/Contextual)
[![License](https://img.shields.io/cocoapods/l/Contextual.svg?style=flat)](http://cocoadocs.org/docsets/Contextual)
[![Platform](https://img.shields.io/cocoapods/p/Contextual.svg?style=flat)](http://cocoadocs.org/docsets/Contextual)

Support iOS 15.0 and above

## CocoaPods Installation

Simply add the following into your Podfile:

```bash
pod "Contextual"
```

## For more information including SPM installation

[Documentation](https://docs.contextu.al)

[Contextual Dashboard](https://dashboard.contextu.al/)

## Author

Contextual (support@contextu.al)

## License

The Contextual iOS SDK is available under the LGPL license. See the LICENSE file for more info.