/*
 * Copyright (c) Contextual, All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3.0 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library.
 */

#import <UIKit/UIKit.h>

@interface SHUIElementManager : NSObject

/**
 Singleton creator.
 */
+ (SHUIElementManager *)sharedInstance;

/**
 Get corresponding UIView object. 
 */
- (UIView *)getView:(id)element;

/**
 When submit screenshot or super tag, the element needs a unique id.
 First try reference property, then try display text.
 */
- (NSString *)getUniqueId:(id)element;

/**
 When submit super tag, the metadata needs a friendly when possible.
 */
- (NSString *)getFriendlyName:(id)element;

/**
 Get property reference name of the UI element. It may from IBOutlet or manually create.
 Go through all properties of view controller and find possible match property.
 */
- (NSString *)getPropertyReference:(id)element;

/**
 Get the display text on a UI element control, for example text on label.
 */
- (NSString *)getDisplayText:(id)element;

/**
 Get frame on screen coordinate system.
 */
- (CGRect)getFrameOnScreen:(id)element;

/**
 Get background color of the UI element.
 */
- (UIColor *)getBackgroundColor:(id)element;

/**
 Get preferred text color.
 */
- (UIColor *)getTextColor:(id)element;

/**
 Get preferred text font.
 */
- (UIFont *)getTextFont:(id)element;

/**
 When author an element, get the recognizable sub views.
 */
- (NSArray *)getRecognizableSubviews:(id)element;

/**
 Find a UIView for given display text. If UIBarButtonItem, it's the inner view property.
 */
- (UIView *)findViewByDisplayText:(NSString *)displayText inViewController:(UIViewController *)viewController;

/**
 Add an event to a UI element.
 */
- (void)hookEventForElement:(id)element withTarget:(id)target withSelector:(SEL)selector;

/**
 Add an event to a UI element.
 */
- (void)hookClickEventForElement:(id)element withTarget:(id)target withSelector:(SEL)selector;

/**
 Remove an event from a UI element.
 */
- (void)removeEventForElement:(id)element withTarget:(id)target withSelector:(SEL)selector;

/**
 Remove an event from a UI element.
 */
- (void)removeClickEventForElement:(id)element withTarget:(id)target withSelector:(SEL)selector;

@end
