//
//  WidgetTargetting.h
//  Contextual
//
//  Created by Xingyuji on 22/5/18.
//  Copyright © 2018 Contextual. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol SHWidgetTargettingProtocol <NSObject>

@property NSString *version;

- (NSArray*)generateAuthorMetaData:(NSArray *)exceptViews;
- (UIView*)rematchWidget:(id)sender;

@optional
- (NSString*)getNormalisedViewHierarchy:(UIView *) targetView isNodeLeaf:(BOOL) isNodeLeaf;

@optional
- (void)superTagEventHandler:(UIControl *)sender;

@optional
- (void)findClickableWidgetsToBindSuperTag:(id)sender;

@optional
- (void)authorSubviewsTo:(NSMutableArray *)arrayControls forViews:(NSArray<id> *)views
        inViewController:(UIViewController *)viewController except:(NSArray *)exceptViews;

@optional
- (void)authorNavigationBarButtonItems:(NSMutableArray *)arrayControls
                      inNavigationItem:(UINavigationItem *)navigationItem
                      inViewController:(UIViewController *)viewController
                                except:(NSArray *)exceptViews;
@optional
- (void)authorTabBarButtonItems:(NSMutableArray *)arrayControls
                       inTabBar:(UITabBar *)tabBar
               inViewController:(UIViewController *)viewController
                         except:(NSArray *)exceptViews;
@optional
- (void)authorNavigationToolBarButtonItems:(NSMutableArray *)arrayControls
                                 inToolBar:(UIToolbar *)toolBar
                          inViewController:(UIViewController *)viewController
                                    except:(NSArray *)exceptViews;

@end
