//
//  ContextualBaseCollectionViewController.h
//  ContextualSDK
//
//  Created by Marc Stroebel on 22/8/2023.
//  Copyright © 2023 Contextual. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SHTypes.h"

NS_ASSUME_NONNULL_BEGIN

/**
 Base class for all view controller inherit from UICollectionViewController. It sends logs when enter/exit this VC.
 */
@interface ContextualBaseCollectionViewController : UICollectionViewController <ISHDeepLinking,UIAdaptivePresentationControllerDelegate>

/**
 Some customer view controller may be inherited not in purpose (such as base vc do inherit).
 Use this property to exclude them from being treated as Contextual behavior vc.
 */
@property (nonatomic) BOOL excludeBehavior;

/**
 When custom feed received, sdk call this delegate.
 */
@property (nonatomic, weak) id<ISHCustomFeed> customFeedDelegate;

@end

NS_ASSUME_NONNULL_END
