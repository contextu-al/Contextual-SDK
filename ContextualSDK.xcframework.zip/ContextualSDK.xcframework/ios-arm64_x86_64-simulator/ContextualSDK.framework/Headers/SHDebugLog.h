//
//  SHDebugLog.h
//  Contextual
//
//  Created by ganesh faterpekar on 11/15/19.
//  Copyright © 2022 Contextual. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef SH_DEBULOG_H
#define SH_DEBULOG_H

extern NSString * const activityName;
FOUNDATION_EXPORT void SHLog(NSInteger level, NSString *format,...);
#endif

