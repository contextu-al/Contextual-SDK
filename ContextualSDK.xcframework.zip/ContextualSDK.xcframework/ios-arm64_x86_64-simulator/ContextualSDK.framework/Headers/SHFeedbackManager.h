/*
 * Copyright (c) Contextual, All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3.0 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library.
 */

#import <Foundation/Foundation.h>
#import "SHTypes.h"
#import "SHTipFeedbackElement.h"

/**
 It's possible to call API `-(void)shFeedback:(NSArray *)arrayChoice needInputDialog:(BOOL)needInput needConfirmDialog:(BOOL)needConfirm withTitle:(NSString *)infoTitle withMessage:(NSString *)infoMessage` many times, if previous choice is not submitted yet, next choice should wait and not show till user finish previous one. This queue is to hold and handle it.
 */
@interface SHFeedbackManager : NSObject

/**
 Singleton instance.
 */
+ (nonnull SHFeedbackManager *)shared;

/**
 Get extra json requirements for the specified Feedback element
 */
- (NSDictionary*)getExtraJsonForFeedback:(SHTipFeedbackElement*)feedback;

/**
 Submit feedback to Contextual server.
 */
- (void)submitFeedbackWithTitle:(NSString *)feedbackTitle
                       withType:(NSInteger)feedbackType
                    withContent:(NSString *)feedbackContent
                 withCampaignID:(NSString *)campaignID
                     withFeedId:(NSString *)feedId
                     withStepId:(NSInteger) stepId
                  withExtraJson:(NSDictionary*)extraJson
                    withHandler:(SHCallbackHandler)handler;

@end
