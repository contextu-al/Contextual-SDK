/*
 * Copyright (c) Contextual, All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3.0 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library.
 */

#ifndef SH_Types_h
#define SH_Types_h

/**
 Callback handler with a result or an error.
 
 * If successfully result is the requested object, error is nil.
 * if fail result is nil, error is NSError for failure details.
 */
typedef void (^SHCallbackHandler)(NSObject *result, NSError *error);

// Enum for result.
// */
enum SHResult
{
    /**
     Result when click positive button such as "Agree", "Yes Please".
     */
    SHResult_Accept = 1,
    /**
     Result when click neutral button such as "Later", "Not now".
     */
    SHResult_Postpone = 0,
    /**
     Result when click negative button such as "Never", "Cancel".
     */
    SHResult_Decline = -1,

    /**
     Result when  user click on Previous.
    */
    SHResult_Previous = 2,

    /**
    Result when  user click on next.
    */
    SHResult_Next = 3,

    /**
    Result when  user swipe on carousels.
    */
    SHResult_Page_Change = 4
};
typedef enum SHResult SHResult;

enum SHAppFGBG
{
    SHAppFGBG_Unknown,
    SHAppFGBG_FG,
    SHAppFGBG_BG,
};
typedef enum SHAppFGBG SHAppFGBG;

/**
 Protocol for deal with deeplinking. `ContextualBaseViewController`, `ContextualBaseTableViewController` and `ContextualBaseCollectionViewController` conform this protocol, customer App's view controller is recommended to inherit from `ContextualBaseViewController`, `ContextualBaseTableViewController` or `ContextualBaseCollectionViewController`, so can implement this protocol. Or customer's App's view controller can directly conform this protocol for deeplinking.
 */
@protocol ISHDeepLinking <NSObject>

@optional

/**
 Implement this function for receive deeplinking parameters. Customer App needs to hold the pass in `dictParam` in some internal data structure, cannot rely on this function to show to UI. Because this function is called before UI loaded, the controls are not created yet. `ContextualBaseViewController`, `ContextualBaseTableViewController` or `ContextualBaseCollectionViewController` automatically calls `displayDeepLinkingToUI` on `viewDidLoad` to display data to UI.
 @param dictParam Pass in parameters.
 */
- (void)receiveDeepLinkingData:(NSDictionary *)dictParam;

/**
 Implement this function if need to show deeplinking data to UI. The data was received in `receiveDeepLinkingData:` before UI loaded, and it should be stored in customer's view controller internal data. Call this function whenever it's ready to show data to UI controller. `viewDidLoad` is already automatically called by `ContextualBaseViewController`, `ContextualBaseTableViewController` or `ContextualBaseCollectionViewController`.
 */
- (void)displayDeepLinkingToUI;

@end

/**
 Protocol for deal with custom feed. Customer App's view controller is recommended to inherit from `ContextualBaseViewController`, `ContextualBaseTableViewController` or `ContextualBaseCollectionViewController`, so can implement this protocol by set customFeedDelegate.
 */
@protocol ISHCustomFeed <NSObject>

@required

/**
 Implement this function for receive custom feed. Set customFeedDelegate in view controller inherited from `ContextualBaseViewController`, `ContextualBaseTableViewController` or `ContextualBaseCollectionViewController`.
 @param feed Pass in parameters.
 */
- (void)receiveCustomFeed:(id)feed;

@end

/**
 Category extension of UIViewController.
 */
@interface UIViewController (SHViewExt)

/**
 Show self VC's view on top.
 @param needCover When showing self's view, whether need a cover view behide it. Sometimes it needs a light transparanet color cover.
 @param coverColor Optional, only take effect when needCover = YES; It has default value `lightGrayColor` when it's nil.
 @param coverAlpha Optional, only take effect when needCover = YES; It has default value 0.5 when it's 0. If it's really want to be 0, set needCover = NO.
 @param needDelay By default it needs delay 0.5 second to let transition view gone. But if it already has delay, this can be set to NO to avoid too much delay.
 @param coverTouchHandler Callback when touch cover. Must have needCover=YES to work. The touchPoint is in cover full screen range.
 @param animationHandler Callback when need caller to show by changing self view's frame. The pass in rect is orientated root rect.
 @param orientationChangedHandler Callback when orientation changed. Must have needCover=YES to work.
 */
- (void)presentOnTopWithCover:(BOOL)needCover
               withCoverColor:(UIColor *)coverColor
               withCoverAlpha:(CGFloat)coverAlpha
                    withDelay:(BOOL)needDelay
        withCoverTouchHandler:(void (^)(CGPoint touchPoint))coverTouchHandler
         withAnimationHandler:(void (^)(CGRect fullScreenRect))animationHandler
        withOrientationChangedHandler:(void (^)(CGRect))orientationChangedHandler;

- (void)dismissLauncherButton;

/**
 Dismiss self VC's view from top.
 */
- (void)dismissOnTop;

@end


/**
 Defined as common error domain reported from Contextual.
 */
#define SHErrorDomain  @"SHErrorDomain"

/**
 Make sure not pass nil or NSNull, this is useful to avoid insert nil to NSArray and cause crash.
 */
#define NONULL(str)     ((str && str != (id)[NSNull null]) ? (str) : @"")
#define NOTNIL(obj)     ((id) obj == nil? nil : (id) NONULL([obj class]))
#define REGULAR_HEARTBEAT_LOGTIME       @"REGULAR_HEARTBEAT_LOGTIME"
#define REGULAR_LOCATION_LOGTIME        @"REGULAR_LOCATION_LOGTIME"


//NSUserDefaults value for passing value between modules. It's not used as local cache for location, and before use it must have notification "SH_LMBridge_UpdateGeoLocation" to update the value.
#define SH_GEOLOCATION_LAT      @"SH_GEOLOCATION_LAT"
#define SH_GEOLOCATION_LNG      @"SH_GEOLOCATION_LNG"
#define SH_LOCATION_STATUS      @"SH_LOCATION_STATUS"
//For get/set App install token
#define SH_INSTALL_TOKEN        @"SH_INSTALL_TOKEN"

#define SH_TARGETTING_ALGORITHM_VERSION      @"3.0.0" //key for version of targetting alogrithm

#endif
