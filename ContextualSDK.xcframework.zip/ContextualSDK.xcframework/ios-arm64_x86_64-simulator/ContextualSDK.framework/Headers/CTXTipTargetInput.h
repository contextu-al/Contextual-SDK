//
//  CTXTipTargetInput.h
//  ContextualSDK
//
//  Created by admin on 17/08/2023.
//  Copyright © 2023 Contextual. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CTXTipTargetInput : NSObject
@property (nonatomic, strong) NSString *target;
@end

NS_ASSUME_NONNULL_END
