//
//  LegacyScreenShotCapturer.h
//  ContextualSDK
//
//  Created by Marc Stroebel on 21/8/2023.
//  Copyright © 2023 Contextual. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol CTXITipManager;

@interface CTXLegacyScreenShotCapturer : NSObject

+ (void)captureScreenShot;

@end

NS_ASSUME_NONNULL_END
