//
//  CTXTipTarget.h
//  ContextualSDK
//
//  Created by admin on 17/08/2023.
//  Copyright © 2023 Contextual. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CTXTipTargetInput.h"

NS_ASSUME_NONNULL_BEGIN

@interface CTXTipTarget : NSObject
@property (nonatomic, strong) NSString *alg;
@property (nonatomic, strong) NSString *version;
@property (nonatomic, strong) NSArray<CTXTipTargetInput *> *inputs;

+ (instancetype)createFromTarget:(NSDictionary *)dictPayload;

@end

NS_ASSUME_NONNULL_END
