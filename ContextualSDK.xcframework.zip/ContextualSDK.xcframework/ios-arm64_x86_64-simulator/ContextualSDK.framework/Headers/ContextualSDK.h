/*
 * Copyright (c) Contextual, All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3.0 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library.
 */

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

//! Project version number for ContextualSDK.
FOUNDATION_EXPORT double ContextualSDKVersionNumber;

//! Project version string for ContextualSDK.
FOUNDATION_EXPORT const unsigned char ContextualSDKVersionString[];

// Core
#import "Contextual.h"
#import "ContextualBaseViewController.h"
#import "ContextualBaseTableViewController.h"
#import "ContextualBaseCollectionViewController.h"
#import "SHFriendlyNameObject.h"
#import "SHObject.h"
#import "SHTypes.h"
#import "SHUtils.h"
#import "SHDebugLog.h"
#import "SHUIElementManager.h"
// Feed
#import "SHFeedObject.h"
#import "SHApp+Feed.h"

// Contextual
#import "SHTipBaseElement.h"
#import "SHTipDef.h"
#import "SHTipImageElement.h"
#import "SHTipTextElement.h"
#import "SHTipButtonElement.h"
#import "SHTipWebElement.h"
#import "SHTipDismissElement.h"
#import "SHTipLauncherElement.h"
#import "SHTipCoachmarkElement.h"
#import "SHTipTargetElement.h"
#import "SHTipElement.h"
#import "SHTipSeriesElement.h"
#import "SHTipAnimationElement.h"
#import "SHTipCarouselElement.h"
#import "SHTipFeedbackElement.h"
#import "SHTipManager.h"
#import "SHFeedConditions.h"
#import "SHFeedbackManager.h"
#import "SHCoverView.h"
#import "CTXLegacyScreenShotCapturer.h"
#import "CTXTipTarget.h"
#import "CTXTipTargetInput.h"
